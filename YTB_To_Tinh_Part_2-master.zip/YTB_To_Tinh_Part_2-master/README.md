### [Tỏ Tình theo phong cách của một IT || Part 2](https://youtu.be/JBEzJTogHCM)
> Các bạn download source về và làm theo hương dẫn trong video nhé.
